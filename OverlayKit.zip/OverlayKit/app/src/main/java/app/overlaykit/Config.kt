package app.overlaykit

object Config {
    @Volatile var esp = true
    @Volatile var tracer = true
    @Volatile var proximityWarning = true
    @Volatile var warnRadius = 0.25f // in screen heights

    // Uncalibrated: where the local brawler sits on screen (normalized 0..1).
    @Volatile var playerX = 0.5f
    @Volatile var playerY = 0.5f

    @Volatile var detector = DetectorConfig()
}
