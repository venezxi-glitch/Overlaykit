package app.overlaykit

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

// All values are uncalibrated defaults. They must be tuned against real screenshots.
data class DetectorConfig(
    val redMin: Int = 170,
    val otherMaxPercent: Int = 40,
    val minBarW: Float = 0.015f,
    val maxBarW: Float = 0.10f,
    val minBarH: Float = 0.002f,
    val maxBarH: Float = 0.02f,
    val roiLeft: Float = 0.0f,
    val roiRight: Float = 1.0f,
    val roiTop: Float = 0.08f,
    val roiBottom: Float = 0.78f,
    val boxWidthMul: Float = 1.2f,
    val boxHeightMul: Float = 1.5f,
    val boxGapPx: Float = 1f,
)

class Bar(var x0: Int, var x1: Int, var y0: Int, var y1: Int)

data class Target(val l: Float, val t: Float, val r: Float, val b: Float, val dist: Float)

object Detector {

    fun isEnemyRed(p: Int, c: DetectorConfig): Boolean {
        val r = (p shr 16) and 255
        val g = (p shr 8) and 255
        val b = p and 255
        return r >= c.redMin && g * 100 <= r * c.otherMaxPercent && b * 100 <= r * c.otherMaxPercent
    }

    /** px is packed 0x00RRGGBB, size w*h. Returns thin horizontal red bars. */
    fun detect(px: IntArray, w: Int, h: Int, c: DetectorConfig): List<Bar> {
        if (w <= 0 || h <= 0 || px.size < w * h) return emptyList()
        val minRun = max(2, (w * c.minBarW).roundToInt())
        val maxRun = max(minRun, (w * c.maxBarW).roundToInt())
        val minH = max(1, (w * c.minBarH).roundToInt())
        val maxH = max(minH, (w * c.maxBarH).roundToInt())
        val yStart = (h * c.roiTop).toInt().coerceIn(0, h)
        val yEnd = (h * c.roiBottom).toInt().coerceIn(yStart, h)
        val xStart = (w * c.roiLeft).toInt().coerceIn(0, w)
        val xEnd = (w * c.roiRight).toInt().coerceIn(xStart, w)

        var open = ArrayList<Bar>()
        val done = ArrayList<Bar>()
        for (y in yStart until yEnd) {
            val next = ArrayList<Bar>()
            val row = y * w
            var x = xStart
            while (x < xEnd) {
                if (!isEnemyRed(px[row + x], c)) { x++; continue }
                val s = x
                while (x < xEnd && isEnemyRed(px[row + x], c)) x++
                val e = x - 1
                val len = e - s + 1
                if (len < minRun || len > maxRun) continue
                var m: Bar? = null
                for (b in open) {
                    if (b.y1 == y - 1 && s <= b.x1 && e >= b.x0) { m = b; break }
                }
                if (m != null) {
                    m.x0 = min(m.x0, s)
                    m.x1 = max(m.x1, e)
                    m.y1 = y
                    if (!next.contains(m)) next.add(m)
                } else {
                    next.add(Bar(s, e, y, y))
                }
            }
            for (b in open) if (b.y1 != y) done.add(b)
            open = next
        }
        done.addAll(open)

        return done.filter {
            val bw = it.x1 - it.x0 + 1
            val bh = it.y1 - it.y0 + 1
            bh in minH..maxH && bw in minRun..maxRun && bw >= bh * 3
        }
    }

    /** Boxes are estimated below each bar. Distance is in screen heights. Result is sorted nearest first. */
    fun buildTargets(bars: List<Bar>, w: Int, h: Int, c: DetectorConfig, playerX: Float, playerY: Float): List<Target> {
        val aspect = w.toFloat() / h
        return bars.map { bar ->
            val barW = (bar.x1 - bar.x0 + 1).toFloat()
            val cx = (bar.x0 + bar.x1 + 1) / 2f
            val boxW = barW * c.boxWidthMul
            val boxH = barW * c.boxHeightMul
            val top = bar.y1 + 1f + c.boxGapPx
            val l = (cx - boxW / 2f) / w
            val r = (cx + boxW / 2f) / w
            val t = top / h
            val b = (top + boxH) / h
            val dx = ((l + r) / 2f - playerX) * aspect
            val dy = (t + b) / 2f - playerY
            Target(l, t, r, b, sqrt(dx * dx + dy * dy))
        }.sortedBy { it.dist }
    }
}
