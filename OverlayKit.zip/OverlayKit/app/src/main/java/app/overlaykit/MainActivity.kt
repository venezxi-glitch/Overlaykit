package app.overlaykit

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private val reqCapture = 1
    private val reqNotif = 2
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(28), dp(28), dp(28))
            setBackgroundColor(0xFF0F1117.toInt())
        }
        val title = TextView(this).apply {
            text = "Overlay Kit"; setTextColor(Color.WHITE); textSize = 28f; gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        status = TextView(this).apply {
            text = "Grant overlay and screen capture access, then Brawl Stars opens with the menu on top."
            setTextColor(0xFF9AA0B4.toInt()); textSize = 14f; gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(24))
        }
        val start = Button(this).apply {
            text = "Start"; setTextColor(Color.WHITE); isAllCaps = false; textSize = 16f
            background = GradientDrawable().apply { setColor(0xFF7C5CFF.toInt()); cornerRadius = dp(16).toFloat() }
            setOnClickListener { begin() }
        }
        root.addView(title)
        root.addView(status)
        root.addView(start, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)))
        setContentView(root)
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Allow \"Display over other apps\" for Overlay Kit, then press Start again."
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqNotif) begin()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqCapture) return
        if (resultCode != RESULT_OK || data == null) {
            status.text = "Screen capture was not allowed."
            return
        }
        startForegroundService(
            Intent(this, CaptureService::class.java)
                .putExtra(CaptureService.EXTRA_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
        )
        val launch = packageManager.getLaunchIntentForPackage("com.supercell.brawlstars")
        if (launch != null) startActivity(launch)
        else status.text = "Running, but Brawl Stars was not found. Open it manually."
    }
}
