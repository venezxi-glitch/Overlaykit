package app.overlaykit

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

class OverlayView(ctx: Context) : View(ctx) {

    @Volatile private var targets: List<Target> = emptyList()

    // Colors avoid red on purpose so the overlay is not detected by its own capture.
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f; color = 0xFF00E5FF.toInt()
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.5f; color = 0xFFFFEA00.toInt()
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textSize = 28f; setShadowLayer(4f, 0f, 0f, 0xFF000000.toInt())
    }
    private val warnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 14f; color = 0xFFFF00FF.toInt()
    }

    fun update(t: List<Target>) {
        targets = t
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val t = targets
        val w = width.toFloat()
        val h = height.toFloat()
        if (t.isEmpty()) return

        if (Config.esp) {
            for (e in t) {
                c.drawRect(e.l * w, e.t * h, e.r * w, e.b * h, boxPaint)
                c.drawText("%.2f".format(e.dist), e.l * w, e.b * h + 30f, textPaint)
            }
        }
        if (Config.tracer) {
            val n = t[0]
            c.drawLine(Config.playerX * w, Config.playerY * h, (n.l + n.r) / 2f * w, (n.t + n.b) / 2f * h, linePaint)
        }
        if (Config.proximityWarning && t[0].dist < Config.warnRadius) {
            c.drawRect(7f, 7f, w - 7f, h - 7f, warnPaint)
        }
    }
}
